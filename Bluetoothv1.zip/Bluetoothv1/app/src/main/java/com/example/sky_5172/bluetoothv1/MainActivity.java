package com.example.sky_5172.bluetoothv1;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    public String address_send;
    TextView txtv;
    ListView lv;
    ArrayList<String> mArrayAdapter = null;
    ArrayAdapter<String> adapter = null;
    public static String EXTRA_ADDRESS="device_address";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // lien ket du lieu voi giao dien
        txtv = (TextView) findViewById(R.id.txtv);

        //khoi tao doi tuong dieu khien Bluetooth
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            txtv.setText("Device doesn't support Bluetooth");
        }
        if (!mBluetoothAdapter.isEnabled()) {  //neu Bluetooth chua duoc bat
            //Goi Intent bat bluetooth
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            // Yeu cau bat bluetooth
            startActivityForResult(enableBtIntent, 1);
        }

        //Tim kiem thiet bi da ghep doi
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        // Cai dat list view hien thi danh sach thiet bi da ket noi
        lv = (ListView) findViewById(R.id.listView);
        mArrayAdapter = new ArrayList<String>();
        adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, mArrayAdapter);
        lv.setAdapter(adapter);

        if (pairedDevices.size() > 0) { //neu co thiet bi duoc ghep doi thi hien thi danh sach
            // duyet danh sach thiet bi da ghep doi
            for (BluetoothDevice device : pairedDevices) {
                // Them ten va dia chi cua thiet bi vao danh sach
                mArrayAdapter.add(device.getName() + "\n" + device.getAddress() + ";\n");
                address_send=device.getAddress();
                // Thong bao ListView da thay doi
                adapter.notifyDataSetChanged();
            }
        } else { // neu khong co thiet bi nao da duoc ghep noi thi hien thi khong co thiet bi
            mArrayAdapter.add("Don't Have Paired Devices\n");
            adapter.notifyDataSetChanged();
        }
        lv.setOnItemClickListener(myListClickListener);

//        //*//**//*Discovering devices
//        // Create a BroadcastReceiver for ACTION_FOUND
//        final BroadcastReceiver mReceiver = new BroadcastReceiver() {
//            public void onReceive(Context context, Intent intent) {
//                String action = intent.getAction();
//                // When discovery finds a device
//                if (BluetoothDevice.ACTION_FOUND.equals(action)) {
//                    // Get the BluetoothDevice object from the Intent
//                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
//                    // Add the name and address to an array adapter to show in a ListView
//                    mArrayAdapter.add(device.getName() + "\n" + device.getAddress());
//                    adapter.notifyDataSetChanged();
//                }
//            }
//        };
//// Register the BroadcastReceiver
//        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
//        registerReceiver(mReceiver, filter); // Don't forget to unregister during onDestroy
//
//        Toast.makeText(this, "Control Blutooth Car", Toast.LENGTH_SHORT).show();
//        Log.d("Message", "This is OK");*/

    }

    private AdapterView.OnItemClickListener myListClickListener=new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String info=((TextView) view).getText().toString();
            String address=info.substring(info.length() - 17); // dia chi MAC la 17 ky tu cuoi
            address=address.substring(0,address.length()-2);
            //Tao intent de sang activity dieu khien xe
            Intent i=new Intent(MainActivity.this,control.class);

            //doi activity
            i.putExtra(EXTRA_ADDRESS,address_send);
            startActivity(i);
        }
    };
}
